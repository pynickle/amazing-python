you can use this in the command line,the tool will pack all py files under the path you enter,this is a example::

    pack -p path

you can also remove all exe under the path before packing::
        
    pack -r -p path
    
use pack -h to get more information
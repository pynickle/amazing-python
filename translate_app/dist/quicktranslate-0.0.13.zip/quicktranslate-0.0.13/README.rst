**you can use this in the command line,this is a example**::

    trans -t example

**or**::
    
    trans --trans example

**'example' means what you want to translate**
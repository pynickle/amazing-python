Q&A
===

Question
^^^^^^^^
**l find exe files' and py files' running results are different**

Answer
^^^^^^
**It may cause by not updating exe on time,the py files are the latest**
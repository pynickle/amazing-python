------------
开源项目声明
------------

.. raw:: html

   <table>
     <tr>
       <th>

license

.. raw:: html

   </th>
       <td>

MIT license

.. raw:: html

   </td>
     </tr>
     <tr>
       <th>

author

.. raw:: html

   </th>
       <td>

code-nick-python

.. raw:: html

   </td>
     </tr>
   </table>
